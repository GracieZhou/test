//<MStar Software>
//******************************************************************************
// MStar Software
// Copyright (c) 2010 - 2014 MStar Semiconductor, Inc. All rights reserved.
// All software, firmware and related documentation herein ("MStar Software") are
// intellectual property of MStar Semiconductor, Inc. ("MStar") and protected by
// law, including, but not limited to, copyright law and international treaties.
// Any use, modification, reproduction, retransmission, or republication of all 
// or part of MStar Software is expressly prohibited, unless prior written 
// permission has been granted by MStar. 
//
// By accessing, browsing and/or using MStar Software, you acknowledge that you
// have read, understood, and agree, to be bound by below terms ("Terms") and to
// comply with all applicable laws and regulations:
//
// 1. MStar shall retain any and all right, ownership and interest to MStar
//    Software and any modification/derivatives thereof.
//    No right, ownership, or interest to MStar Software and any
//    modification/derivatives thereof is transferred to you under Terms.
//
// 2. You understand that MStar Software might include, incorporate or be
//    supplied together with third party`s software and the use of MStar
//    Software may require additional licenses from third parties.  
//    Therefore, you hereby agree it is your sole responsibility to separately
//    obtain any and all third party right and license necessary for your use of
//    such third party`s software. 
//
// 3. MStar Software and any modification/derivatives thereof shall be deemed as
//    MStar`s confidential information and you agree to keep MStar`s 
//    confidential information in strictest confidence and not disclose to any
//    third party.  
//
// 4. MStar Software is provided on an "AS IS" basis without warranties of any
//    kind. Any warranties are hereby expressly disclaimed by MStar, including
//    without limitation, any warranties of merchantability, non-infringement of
//    intellectual property rights, fitness for a particular purpose, error free
//    and in conformity with any international standard.  You agree to waive any
//    claim against MStar for any loss, damage, cost or expense that you may
//    incur related to your use of MStar Software.
//    In no event shall MStar be liable for any direct, indirect, incidental or
//    consequential damages, including without limitation, lost of profit or
//    revenues, lost or damage of data, and unauthorized system use.
//    You agree that this Section 4 shall still apply without being affected
//    even if MStar Software has been modified by MStar in accordance with your
//    request or instruction for your use, except otherwise agreed by both
//    parties in writing.
//
// 5. If requested, MStar may from time to time provide technical supports or
//    services in relation with MStar Software to you for your use of
//    MStar Software in conjunction with your or your customer`s product
//    ("Services").
//    You understand and agree that, except otherwise agreed by both parties in
//    writing, Services are provided on an "AS IS" basis and the warranty
//    disclaimer set forth in Section 4 above shall apply.  
//
// 6. Nothing contained herein shall be construed as by implication, estoppels
//    or otherwise:
//    (a) conferring any license or right to use MStar name, trademark, service
//        mark, symbol or any other identification;
//    (b) obligating MStar or any of its affiliates to furnish any person,
//        including without limitation, you and your customers, any assistance
//        of any kind whatsoever, or any information; or 
//    (c) conferring any license or right under any intellectual property right.
//
// 7. These terms shall be governed by and construed in accordance with the laws
//    of Taiwan, R.O.C., excluding its conflict of law rules.
//    Any and all dispute arising out hereof or related hereto shall be finally
//    settled by arbitration referred to the Chinese Arbitration Association,
//    Taipei in accordance with the ROC Arbitration Law and the Arbitration
//    Rules of the Association by three (3) arbitrators appointed in accordance
//    with the said Rules.
//    The place of arbitration shall be in Taipei, Taiwan and the language shall
//    be English.  
//    The arbitration award shall be final and binding to both parties.
//
//******************************************************************************
//<MStar Software>

#ifndef H_HDCP_COMMON_H
#define H_HDCP_COMMON_H

#ifndef DLL_PUBLIC
#define DLL_PUBLIC __attribute__ ((visibility ("default")))
#endif

#ifdef __cplusplus
extern "C"
{
#endif

typedef enum
{
    EN_HDCP_TYPE_HDMI = 0,
    EN_HDCP_TYPE_MIRACAST
} EN_HDCP_TYPE;

typedef struct HDCP_CONFIG
{
    int nDscmbEnable;             /// enable dscmb or not, ex: nugget doesn't have dscmb feature.
    int nFacsimileRxEnable;       /// enable facsimile rx key or not
    int nFacsimileTxEnable;       /// enable facsimile tx key or not
    int nFacsimileRxVerifyEnable; /// enable facsimile rx verify or not
    int nFacsimileTxVerifyEnable; /// enable facsimile tx verify or not
    int nDscmbOperationType;      /// dscmb operation type.
                                  /// 0: create all dscmb filter and connect all dmx filter
                                  /// 1: base on specified dmx filter count to create dscmb filter and connect them
}ST_HDCP_CONFIG;

typedef enum
{
    EN_HDCP_ERR_NA = 0,
    EN_HDCP_ERR_NULL_MESSAGE,
    EN_HDCP_ERR_AKE_INIT,
    EN_HDCP_ERR_AKE_SEND_CERT,
    EN_HDCP_ERR_AKE_NO_STORED_KM,
    EN_HDCP_ERR_AKE_STORED_KM,
    EN_HDCP_ERR_AKE_SEND_RRX,
    EN_HDCP_ERR_AKE_SEND_H_PRIME,
    EN_HDCP_ERR_AKE_SEND_PAIRING_INFO,
    EN_HDCP_ERR_LC_INIT,
    EN_HDCP_ERR_LC_SEND_L_PRIME,
    EN_HDCP_ERR_SKE_SEND_EKS,
    EN_HDCP_ERR_REPEATERAUTH_SEND_RECEIVERID_LIST,
    EN_HDCP_ERR_RTT_READY,
    EN_HDCP_ERR_RTT_CHALLENGE,
    EN_HDCP_ERR_REPEATERAUTH_SEND_ACK,
    EN_HDCP_ERR_REPEATERAUTH_STREAM_MANAGE,
    EN_HDCP_ERR_REPEATERAUTH_STREAM_READY,
    EN_HDCP_ERR_RECEIVER_AUTHSTATUS,
    EN_HDCP_ERR_AKE_TRANSMITTER_INFO,
    EN_HDCP_ERR_AKE_RECEIVER_INFO,
    
    EN_HDCP_ERR_HDCP_KEY_IS_NOT_EXISTED,
    
} EN_HDCP_ERROR_TYPE;

/// HDMI usage
typedef void (*Fn_HDCP22_Recv_CBF)(unsigned char, unsigned char, unsigned char*, unsigned long, void*); //type, portIdx, msg, msg length, context

typedef void (*Fn_MDrv_HDCP22_InitCBFunc)(Fn_HDCP22_Recv_CBF pCBFunc, void* pContext);
typedef void (*Fn_MDrv_HDCP22_PortInit)(unsigned char ucPortIdx);
typedef unsigned char (*Fn_MDrv_HDCP22_PollingReadDone)(unsigned char ucPortIdx);
typedef void (*Fn_MDrv_HDCP22_EnableCipher)(unsigned char ucPortType, unsigned char ucPortIdx, unsigned char bIsEnable);
typedef void (*Fn_MDrv_HDCP22_SendMsg)(unsigned char ucPortType, unsigned char ucPortIdx, unsigned char* pucData, unsigned long dwDataLen, void* pDummy);
typedef void (*Fn_MDrv_HDCP22_Handler)(unsigned char ucPortIdx);
typedef void (*Fn_MDrv_HDCP22_FillCipherKey)(unsigned char pucPortIdx, unsigned char* pucRiv, unsigned char* pucSessionKey);


/// Error callback
typedef void (*Fn_HDCP22_Error_CBF)(unsigned int u32State, unsigned int u32SubState, unsigned char* strMsg);

/// Get HDCP key
typedef int (*Fn_HDCP22_GetHdcpKey)(char* strHdcpKeyPath, void* pKeyParam);

#ifdef __cplusplus
}
#endif


#endif
