//<MStar Software>
//******************************************************************************
// MStar Software
// Copyright (c) 2010 - 2015 MStar Semiconductor, Inc. All rights reserved.
// All software, firmware and related documentation herein ("MStar Software") are
// intellectual property of MStar Semiconductor, Inc. ("MStar") and protected by
// law, including, but not limited to, copyright law and international treaties.
// Any use, modification, reproduction, retransmission, or republication of all
// or part of MStar Software is expressly prohibited, unless prior written
// permission has been granted by MStar.
//
// By accessing, browsing and/or using MStar Software, you acknowledge that you
// have read, understood, and agree, to be bound by below terms ("Terms") and to
// comply with all applicable laws and regulations:
//
// 1. MStar shall retain any and all right, ownership and interest to MStar
//    Software and any modification/derivatives thereof.
//    No right, ownership, or interest to MStar Software and any
//    modification/derivatives thereof is transferred to you under Terms.
//
// 2. You understand that MStar Software might include, incorporate or be
//    supplied together with third party`s software and the use of MStar
//    Software may require additional licenses from third parties.
//    Therefore, you hereby agree it is your sole responsibility to separately
//    obtain any and all third party right and license necessary for your use of
//    such third party`s software.
//
// 3. MStar Software and any modification/derivatives thereof shall be deemed as
//    MStar`s confidential information and you agree to keep MStar`s
//    confidential information in strictest confidence and not disclose to any
//    third party.
//
// 4. MStar Software is provided on an "AS IS" basis without warranties of any
//    kind. Any warranties are hereby expressly disclaimed by MStar, including
//    without limitation, any warranties of merchantability, non-infringement of
//    intellectual property rights, fitness for a particular purpose, error free
//    and in conformity with any international standard.  You agree to waive any
//    claim against MStar for any loss, damage, cost or expense that you may
//    incur related to your use of MStar Software.
//    In no event shall MStar be liable for any direct, indirect, incidental or
//    consequential damages, including without limitation, lost of profit or
//    revenues, lost or damage of data, and unauthorized system use.
//    You agree that this Section 4 shall still apply without being affected
//    even if MStar Software has been modified by MStar in accordance with your
//    request or instruction for your use, except otherwise agreed by both
//    parties in writing.
//
// 5. If requested, MStar may from time to time provide technical supports or
//    services in relation with MStar Software to you for your use of
//    MStar Software in conjunction with your or your customer`s product
//    ("Services").
//    You understand and agree that, except otherwise agreed by both parties in
//    writing, Services are provided on an "AS IS" basis and the warranty
//    disclaimer set forth in Section 4 above shall apply.
//
// 6. Nothing contained herein shall be construed as by implication, estoppels
//    or otherwise:
//    (a) conferring any license or right to use MStar name, trademark, service
//        mark, symbol or any other identification;
//    (b) obligating MStar or any of its affiliates to furnish any person,
//        including without limitation, you and your customers, any assistance
//        of any kind whatsoever, or any information; or
//    (c) conferring any license or right under any intellectual property right.
//
// 7. These terms shall be governed by and construed in accordance with the laws
//    of Taiwan, R.O.C., excluding its conflict of law rules.
//    Any and all dispute arising out hereof or related hereto shall be finally
//    settled by arbitration referred to the Chinese Arbitration Association,
//    Taipei in accordance with the ROC Arbitration Law and the Arbitration
//    Rules of the Association by three (3) arbitrators appointed in accordance
//    with the said Rules.
//    The place of arbitration shall be in Taipei, Taiwan and the language shall
//    be English.
//    The arbitration award shall be final and binding to both parties.
//
//******************************************************************************
//<MStar Software>


#ifndef __HDCP_APP_H_
#define __HDCP_APP_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>
#include "hdcpCommon.h"

#define IPADDR_LENGTH    16
#define STREAM_CTR_NUM   5

/// log level
typedef enum
{
    E_HDCP_LOG_DISABLE = 0,
    E_HDCP_LOG_ERR,
    E_HDCP_LOG_INFO,
}EN_HDCP_LOG_LEVEL;

/// hdcp device. RX:reciever TX:transmitter Repeater:reciever+transmitter
typedef enum
{
    E_HDCP_DEVICE_RX = 0,
    E_HDCP_DEVICE_TX,
    E_HDCP_DEVICE_REPEATER,
}EN_HDCP_DEVICE_TYPE;

/// hdcp common data
typedef struct
{
    int                 CommonDataAddress;
    EN_HDCP_DEVICE_TYPE eDeviceType;
    char                szPeerIPAddr[IPADDR_LENGTH+1];
    int                 usHdcpPort;
    int                 sockListen;                     /// useless, keep to sync Gen4 and MCT
    int                 sock;                           /// useless, keep to sync Gen4 and MCT

    EN_HDCP_LOG_LEVEL   eLogLevel;                      /// useless, keep to sync Gen4 and MCT
    long                lTimeoutMultiplier;
    int                 hdcp_canceled;                  /// useless, keep to sync Gen4 and MCT
    int                 bRx;
    uint64_t            aullInputCtr[STREAM_CTR_NUM];
    Fn_HDCP22_Error_CBF pFn_HDCP22_Error_CBF;
    int                 nThreadRunning;                 /// non-zero: thread is running
    int                 nStopActivated;                 /// non-zero: stop miracast is running
}ST_HDCP_COMMON_DATA;

#ifndef DLL_PUBLIC
#define DLL_PUBLIC __attribute__ ((visibility ("default")))
#endif


//////////////////////////////////////////////////////////////////////
/// HDCP2 New APIs definition
/// Note: HDCP2 prefix means new interfaces
//////////////////////////////////////////////////////////////////////

/*** Miracast ***/

/// Start Miracast authentation process.
/// @param pstHdcpConfig       [IN]   common data instance pointer
DLL_PUBLIC int HDCP2_StartMiracast(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Stop Miracast
/// @param pstHdcpConfig       [IN]   common data instance pointer
DLL_PUBLIC int HDCP2_StopMiracast(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Connect dmx filter to dscmb filter
/// @param pstHdcpConfig       [IN]   common data instance pointer
/// @param u8DmxFltId          [IN]   dmx filter id
DLL_PUBLIC int HDCP2_DscmbFltConnectDmxFlt(ST_HDCP_COMMON_DATA* pstHdcpConfig, unsigned char u8DmxFltId);


/// Debug usage
/// Set AES and RIV key to DSCMB engine
/// @param pu8ContentKey          [IN]     Content key (16 Bytes)
/// @param pu8RIV                 [IN]     RIV key (8 Bytes)
DLL_PUBLIC void HDCP2_SetDscmbAesRivKey(unsigned char* pu8ContentKey, unsigned char* pu8RIV);


/*** HDMI ***/

/// Set hdcp key callback function that used to get hdcp key
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetHdcpKeyCB(Fn_HDCP22_GetHdcpKey pFunc);


/// Load HDCP device key.
/// @param bIsRx              [IN]   RX or Tx
DLL_PUBLIC int HDCP2_LoadKey(int bIsRx);


/// Initialize HDMI for HDCP handling.
/// Note: Please set callback function in advance.
/// @param bIsRx              [IN]   RX or Tx
/// @param nPortCount         [IN]   Port count
DLL_PUBLIC void HDCP2_InitHDMI(int bIsRx, int nPortCount);


/// Finialize HDMI for HDCP handling.
/// @param bIsRx              [IN]   RX or Tx
DLL_PUBLIC void HDCP2_DeInitHDMI(int bIsRx);


/// Suspend HDMI for HDCP handling.
/// @param bIsRx              [IN]   RX or Tx
DLL_PUBLIC void HDCP2_SuspendHDMI(int bIsRx);


/// Resume HDMI for HDCP handling.
/// @param bIsRx              [IN]   RX or Tx
DLL_PUBLIC void HDCP2_ResumeHDMI(int bIsRx);


/// Set HDMI InitCBFunc callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetInitCBFuncCB(Fn_MDrv_HDCP22_InitCBFunc pFunc);


/// Set HDMI PortInit callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetPortInitCB(Fn_MDrv_HDCP22_PortInit pFunc);


/// Set HDMI PollingReadDone callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetPollingReadDoneCB(Fn_MDrv_HDCP22_PollingReadDone pFunc);


/// Set HDMI EnableCipher callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetEnableCipherCB(Fn_MDrv_HDCP22_EnableCipher pFunc);


/// Set HDMI FillCipherKey callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetFillCipherKeyCB(Fn_MDrv_HDCP22_FillCipherKey pFunc);


/// Set HDMI SendMsg callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetSendMsgCB(Fn_MDrv_HDCP22_SendMsg pFunc);


/// Set HDMI Handler callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetHandlerCB(Fn_MDrv_HDCP22_Handler pFunc);


/// Set HDMI Error message callback function.
/// @param pFunc              [IN]   callback function
DLL_PUBLIC void HDCP2_SetErrorCB(Fn_HDCP22_Error_CBF pFunc);


/// Debug usage
/// Get HDMI with HDCP2.2 cipher state
/// @param pu32State         [IN]     Port cipher state
/// @Note bit-0:port 1, bit-1: port2, ..., etc (HW level)
DLL_PUBLIC int HDCP_Get_Cipher_State(unsigned int* pu32State);

//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
/// Old interface for Miracast Rx
//////////////////////////////////////////////////////////////////////


/// Run the encryption function
/// @param pu8ContentKey     [IN]     Content key
/// @param pu8IV             [IN]     IV
/// @param nDataBufLen       [IN]     Buffer length
/// @param pDataBuf          [IN/OUT] Encrypted content buffer/Decrypted content buffer
DLL_PUBLIC int HDCP_Decrypt_AesCtr(unsigned char *pu8ContentKey, unsigned char *pu8IV, unsigned int nDataBufLen, unsigned char *pDataBuf);


/// Run the decryption function for TS packet
/// @param pidArray          [IN]     TS packet PID array list
/// @param pidArraySize      [IN]     TS packet PID array size
/// @param pBuf              [IN/OUT] Source and destination buffer
/// @param nBufLen           [IN]     Buffer length
/// @param aesKey            [IN]     AES key
/// @param RIV               [IN]     RIV key(Note: please fill 0x00 to meet 16 bytes due to hw request)
DLL_PUBLIC int HDCP_Aes_Decrypt_TS(uint32_t *pidArray, uint32_t pidArraySize, uint8_t * const pBuf, uint32_t nBufLen, uint8_t *aesKey, uint8_t *RIV);


//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
/// Old interface for Miracast Tx
//////////////////////////////////////////////////////////////////////


/// Initialize HDCP per configuration settings
/// @param pstHdcpConfig     [IN]     HDCP common data
/// @Note1  for rx, set bRx to TRUE, instead tx, set to FALSE
/// @Note2  pleaes give peer ip for tx case
DLL_PUBLIC int HDCP_Initialize(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Finialize HDCP related controls per HDC common data
/// @param pstHdcpConfig     [IN]     HDCP common data
DLL_PUBLIC int HDCP_Finalize(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Run the TX HDCP authentication
/// @param pstHdcpConfig     [IN]     HDCP common data
DLL_PUBLIC int HDCP_TX_StartAuth(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Initialize encryption
/// @param pstHdcpConfig     [IN]     HDCP common data
DLL_PUBLIC int HDCP_Begin_Crypto(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Finialize encryption
/// @param pstHdcpConfig     [IN]     HDCP common data
DLL_PUBLIC int HDCP_End_Crypto(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Run the encryption function
/// @param pstHdcpConfig     [IN]     HDCP common data
/// @param pdst              [OUT]    After encryption content buffer
/// @param psrc              [IN]     Before encryption content buffer
/// @param octetsize         [IN]     Size
/// @param ulStreamCtr       [IN]     Stream counter used for AES-CTR
/// @param pullInputCtr      [OUT]    Input counter used for AES-CTR
DLL_PUBLIC int HDCP_Encrypt(ST_HDCP_COMMON_DATA* pstHdcpConfig, uint8_t* pdst, uint8_t* psrc, int octetsize, uint32_t ulStreamCtr, uint64_t* pullInputCtr);


// TODO:
/// Run the decryption function
/// @param pstHdcpConfig     [IN]     HDCP common data
DLL_PUBLIC int HDCP_Decrypt(ST_HDCP_COMMON_DATA* pstHdcpConfig);


//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
/// Useless API interfaces
//////////////////////////////////////////////////////////////////////


/// Reset hdcp setting
/// @param enLogLevel     [IN]    HDCP log level
DLL_PUBLIC void HDCP_SetDbgLevel(EN_HDCP_LOG_LEVEL enLogLevel);


/// HDCP flow
// HDCP_Reset  -> HDCP_Start -> HDCP_Stop

/// Reset HDCP status
/// @param pstHdcpConfig     [IN]    HDCP common data
DLL_PUBLIC void HDCP_Reset(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Start HDCP status.
/// @param pstHdcpConfig     [IN]    HDCP common data
DLL_PUBLIC int HDCP_Start(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Stop HDCP status.
/// @param pstHdcpConfig     [IN]    HDCP common data
DLL_PUBLIC void HDCP_Stop(ST_HDCP_COMMON_DATA* pstHdcpConfig);


/// Check HDCP support TEE or not.
/// return 1 if support TEE and return 0 if not support
DLL_PUBLIC int HDCP_isSupportTEE();


//////////////////////////////////////////////////////////////////////


#ifdef __cplusplus
}
#endif

#endif // __HDCP_APP_H_
