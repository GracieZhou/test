//<MStar Software>
//******************************************************************************
// MStar Software
// Copyright (c) 2010 - 2014 MStar Semiconductor, Inc. All rights reserved.
// All software, firmware and related documentation herein ("MStar Software") are
// intellectual property of MStar Semiconductor, Inc. ("MStar") and protected by
// law, including, but not limited to, copyright law and international treaties.
// Any use, modification, reproduction, retransmission, or republication of all 
// or part of MStar Software is expressly prohibited, unless prior written 
// permission has been granted by MStar. 
//
// By accessing, browsing and/or using MStar Software, you acknowledge that you
// have read, understood, and agree, to be bound by below terms ("Terms") and to
// comply with all applicable laws and regulations:
//
// 1. MStar shall retain any and all right, ownership and interest to MStar
//    Software and any modification/derivatives thereof.
//    No right, ownership, or interest to MStar Software and any
//    modification/derivatives thereof is transferred to you under Terms.
//
// 2. You understand that MStar Software might include, incorporate or be
//    supplied together with third party`s software and the use of MStar
//    Software may require additional licenses from third parties.  
//    Therefore, you hereby agree it is your sole responsibility to separately
//    obtain any and all third party right and license necessary for your use of
//    such third party`s software. 
//
// 3. MStar Software and any modification/derivatives thereof shall be deemed as
//    MStar`s confidential information and you agree to keep MStar`s 
//    confidential information in strictest confidence and not disclose to any
//    third party.  
//
// 4. MStar Software is provided on an "AS IS" basis without warranties of any
//    kind. Any warranties are hereby expressly disclaimed by MStar, including
//    without limitation, any warranties of merchantability, non-infringement of
//    intellectual property rights, fitness for a particular purpose, error free
//    and in conformity with any international standard.  You agree to waive any
//    claim against MStar for any loss, damage, cost or expense that you may
//    incur related to your use of MStar Software.
//    In no event shall MStar be liable for any direct, indirect, incidental or
//    consequential damages, including without limitation, lost of profit or
//    revenues, lost or damage of data, and unauthorized system use.
//    You agree that this Section 4 shall still apply without being affected
//    even if MStar Software has been modified by MStar in accordance with your
//    request or instruction for your use, except otherwise agreed by both
//    parties in writing.
//
// 5. If requested, MStar may from time to time provide technical supports or
//    services in relation with MStar Software to you for your use of
//    MStar Software in conjunction with your or your customer`s product
//    ("Services").
//    You understand and agree that, except otherwise agreed by both parties in
//    writing, Services are provided on an "AS IS" basis and the warranty
//    disclaimer set forth in Section 4 above shall apply.  
//
// 6. Nothing contained herein shall be construed as by implication, estoppels
//    or otherwise:
//    (a) conferring any license or right to use MStar name, trademark, service
//        mark, symbol or any other identification;
//    (b) obligating MStar or any of its affiliates to furnish any person,
//        including without limitation, you and your customers, any assistance
//        of any kind whatsoever, or any information; or 
//    (c) conferring any license or right under any intellectual property right.
//
// 7. These terms shall be governed by and construed in accordance with the laws
//    of Taiwan, R.O.C., excluding its conflict of law rules.
//    Any and all dispute arising out hereof or related hereto shall be finally
//    settled by arbitration referred to the Chinese Arbitration Association,
//    Taipei in accordance with the ROC Arbitration Law and the Arbitration
//    Rules of the Association by three (3) arbitrators appointed in accordance
//    with the said Rules.
//    The place of arbitration shall be in Taipei, Taiwan and the language shall
//    be English.  
//    The arbitration award shall be final and binding to both parties.
//
//******************************************************************************
//<MStar Software>

#ifndef H_HDCP_CA_H
#define H_HDCP_CA_H

#ifndef DLL_PUBLIC
#define DLL_PUBLIC __attribute__ ((visibility ("default")))
#endif

#ifdef __cplusplus
extern "C"
{
#endif

#include "hdcpCommon.h"

/// structure for HDCP CA Service
typedef struct HDCP_CA_Service
{
    unsigned int m_u32Session; /// Session id for CA-TA communication
    unsigned int m_u32Context; /// HDCP Context Address in TEE
    EN_HDCP_TYPE m_enHdcpType;
}ST_HDCP_CA_SERVICE;

typedef enum
{
    EN_GET_DEVICE_SECRET_KEY_FROM_SECUREREAD = 0,
    EN_GET_DEVICE_SECRET_KEY_INVALID
}EN_GET_DEVICE_SECRET_KEY_METHOD;

typedef enum
{
    EN_SET_KEY_TO_DSCMB = 0, //DSCMB is used by TSP to decrypt encrypted TS data
    EN_SET_KEY_INVALID
}EN_SET_KEY_METHOD;

typedef enum
{
    EN_HDCP_VERSION_2_0 = 0,
    EN_HDCP_VERSION_2_1,
    EN_HDCP_VERSION_2_2
}EN_HDCP_VERSION;

///////////////////////////////////////////////////////////////////////////////////////////////////////
// Recommend.
// The following API are calculated in TEE and will not return the sensitive data to normal world
// For API input with [SENSITIVE] tag is a sensitive data defined in HDCP spec. 
// The following method show how to use [SENSITIVE] input 
//    1. Pass Null to replace the sesentive data input. We will use the sensentive data corresponding 
//       to ST_HDCP_CA_SERVICE
//    2. Pass sensitive data from normal world to override the value kept in secure world
//    
//////////////////////////////////////////////////////////////////////////////////////////////////////// 

///////////////////////////////
/// a. HDCPCA Command
///////////////////////////////

/// Open a session to comunicate between CA-TA and create context in TA side
DLL_PUBLIC int HCS_OpenSession(void);

/// Close a session to comunicate between CA-TA and create context in TA side
DLL_PUBLIC int HCS_CloseSession(void);

/// Open a session to comunicate between CA-TA and create context in TA side
/// @param pstHDCPService       [IN]    HDCP CA instance
DLL_PUBLIC int OpenHDCPService(ST_HDCP_CA_SERVICE *pstHDCPService);

/// Close the session between CA-TA and release all the allocated memory in TA side
/// @param pstHDCPService       [IN]    HDCP CA instance
DLL_PUBLIC int CloseHDCPService(ST_HDCP_CA_SERVICE *pstHDCPService);

/// Set the HDCP configuration to CA-TA
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pstHDCPConfig        [IN]    HDCP config setting
DLL_PUBLIC int HCS_SetConfig(ST_HDCP_CA_SERVICE *pstHDCPService, ST_HDCP_CONFIG* pstHDCPConfig);


//////////////////////////////
/// b. Mstar H/W manipulation 
//////////////////////////////

/// [API for RX]
/// Create hdcp DSCMB session
/// @param pstHDCPService       [IN]    HDCP CA instance
DLL_PUBLIC int HCS_CreateDscmbSession(ST_HDCP_CA_SERVICE *pstHDCPService);

/// [API for RX]
/// Destory hdcp DSCMB session
/// @param pstHDCPService       [IN]    HDCP CA instance
DLL_PUBLIC int HCS_DestoryDscmbSession(ST_HDCP_CA_SERVICE *pstHDCPService);

/// [API for RX]
/// Set AES Key to DSCMB engine
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param enMethod             [IN]    Set Key to which driver
/// @param pu8AESKey            [IN]    [SENSITVE] AES key
/// @param u32AESKeyLen         [IN]    AES key length
DLL_PUBLIC int HCS_SetAESKey(ST_HDCP_CA_SERVICE *pstHDCPService, EN_SET_KEY_METHOD enMethod, unsigned char *pu8AESKey, unsigned int u32AESKeyLen);

/// [API for RX]
/// Set Riv to DSCMB engine
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param enMethod             [IN]    Set Key to which driver
/// @param pu8Riv               [IN]    [SENSITVE] Riv
/// @param u32RivLen            [IN]    Riv length
DLL_PUBLIC int HCS_SetRiv(ST_HDCP_CA_SERVICE *pstHDCPService, EN_SET_KEY_METHOD enMethod, unsigned char *pu8Riv, unsigned int u32RivLen);

/// [API for RX]
/// Set HDCP Target for encrypt/decrypt
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param enMethod             [IN]    Set Key to which driver
/// @param pu8PID               [IN]    PID
/// @param u32PIDLen            [IN]    PID length
/// @param param                [IN]    Reserved
DLL_PUBLIC int HCS_SetHDCPTarget(ST_HDCP_CA_SERVICE *pstHDCPService, EN_SET_KEY_METHOD enMethod, unsigned char *pu8PID, unsigned int u32PIDLen, void *param);

/// [API for Rx]
/// Connect dmx filter to dscmb filter
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param u8DmxFltId           [IN]    Dmx filter ID
DLL_PUBLIC int HCS_DscmbFltConnectDmxFlt(ST_HDCP_CA_SERVICE* pstHDCPService, unsigned char u8DmxFltId);

///////////////////////////////
/// c. Key acquisition 
//////////////////////////////

/// [API for RX] 
/// Acquire Rx Private Key and LC 128 from Secure Storage File and will not return key to normal world
/// @param pstHDCPService       [IN]    HDCP CA instance(not use, keep for backward compatibility)
/// @param enMethod             [IN]    method to get key
/// @param param                [IN]    If method is secure read, you can pass file path to read secret key file
DLL_PUBLIC int HCS_SetRxDeviceSecretKey(ST_HDCP_CA_SERVICE *pstHDCPService, EN_GET_DEVICE_SECRET_KEY_METHOD enMethod, void *param);

/// [API for TX] 
/// Set Tx Device Secret Key including LC128, DCP-LLC Public key to the secure world
/// @param pstHDCPService       [IN]    HDCP CA instance(not use, keep for backward compatibility)
/// @param enMethod             [IN]    method to get key
/// @param param                [IN]    If method is secure read, you can pass file path to read secret key file
DLL_PUBLIC int HCS_SetTxDeviceSecretKey(ST_HDCP_CA_SERVICE *pstHDCPService, EN_GET_DEVICE_SECRET_KEY_METHOD enMethod, void *param);

/// [API for TX/RX] 
/// Get TX/RX Cert Key validity.
/// @param bRx                  [IN]    0 means Rx else Tx
/// @return                             0 means invalid else valid
DLL_PUBLIC int HCS_GetDeviceSecretKeyValidity(int bRx);

/// [API for RX] 
/// Get Rx Cert from Rx Private Key set.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pRxCert              [OUT]   Cert Rx
DLL_PUBLIC int HCS_GetRxCert(ST_HDCP_CA_SERVICE* pstHDCPService, unsigned char* pRxCert);

/// [API for RX]
/// Acquire Master Key by calculating input data in TA and will not return key to normal world. (RSA)
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8EncKm             [IN]    Encrypted Km
/// @param pu8Kpriv_rx          [IN]    [SENSITVE] Key to decrypt encrypted Km
/// @param u32Kpriv_rx_len      [IN]    Key length
DLL_PUBLIC int HCS_SetMasterKeyNoStored(ST_HDCP_CA_SERVICE* pstHDCPService, unsigned char* pu8EncKm, unsigned char* pu8Kpriv_rx, unsigned int u32Kpriv_rx_len);

/// [API for RX]
/// Acquire Master Key by calculating input data in TA and will not return key to normal world. (AES)
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8EncKm             [IN]    Encrypted Km
/// @param pu8M                 [IN]    m 
/// @param pu8Kpriv_rx          [IN]    [SENSITVE] Key to decrypt encrypted Km
/// @param u32Kpriv_rx_len      [IN]    Key length
DLL_PUBLIC int HCS_SetMasterKeyStored(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pu8EncKm, unsigned char *pu8M, unsigned char *pu8Kpriv_rx, unsigned int u32Kpriv_rx_len);

/// [API for RX]
/// Set Rx content key to TA
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8Edkey_ks          [IN]    pu8Edkey_ks
/// @param pu8Riv               [IN]    Riv for content decryption
/// @param pu8Km                [IN]    [SENSITVE]Master key
/// @param pu8Rn                [IN]    Rn
/// @param pu8Rtx               [IN]    Rtx
/// @param pu8Rrx               [IN]    Rrx
/// @param pu8Lc128             [IN]    [SENSITVE]Lc128
DLL_PUBLIC int HCS_SetRxContentKey(ST_HDCP_CA_SERVICE *pstHDCPService,
                                   unsigned char* pu8Edkey_ks, 
                                   unsigned char* pu8Riv, 
                                   unsigned char* pu8Km, 
                                   unsigned char* pu8Rn, 
                                   unsigned char* pu8Rtx, 
                                   unsigned char* pu8Rrx, 
                                   unsigned char* pu8Lc128);

/// [API for TX]
/// Get encrypted master key.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8EncKm             [OUT]   Encrypted Km, length: 128
/// @param pu8RxPubKeyCertN     [IN]    ModN of CertRx
/// @param pu8RxPubKeyCertE     [IN]    Exp of CertRx
DLL_PUBLIC int HCS_GetEncryptKm_No_Stored(ST_HDCP_CA_SERVICE* pstHDCPService,
                                          unsigned char* pu8EncKm,
                                          unsigned char* pu8RxPubKeyCertN,
                                          unsigned char* pu8RxPubKeyCertE);

/// [API for RX]
/// Get encrypted master key.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8EncKm             [OUT]   Encrypted Km. The length will depend on AES
/// @param pu8Km                [IN]    [SENSITVE]Master key
/// @param pu8M                 [IN]    m
/// @param pu8Kpriv_rx          [IN]    [SENSITVE]Key to decrypt encrypted Km
DLL_PUBLIC int HCS_GetEncryptedMasterKeyStored(ST_HDCP_CA_SERVICE *pstHDCPService,
                                               unsigned char* pu8EncKm,
                                               unsigned char* pu8Km,
                                               unsigned char* pu8M,
                                               unsigned char* pu8Kpriv_rx);

/// [API for TX]
/// Get encrypted session key. You should call HCS_SetHDCPVersion before this API
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8Edkey_ks          [OUT]   pu8Edkey_ks
/// @param pu32Edkey_ks_len     [OUT]   pu8Edkey_ks len
/// @param pu8Ks                [IN]    [SENSITVE] Session Key
/// @param pu8Km                [IN]    [SENSITVE] Mster key
/// @param pu8Rn                [IN]    Rn
/// @param pu8Rtx               [IN]    Rtx
/// @param pu8Rrx               [IN]    Rrx
DLL_PUBLIC int HCS_GetEncryptedSessionKey(ST_HDCP_CA_SERVICE *pstHDCPService,
                                          unsigned char** pu8Edkey_ks,
                                          unsigned int* pu32Edkey_ks_len,
                                          unsigned char* pu8Ks, 
                                          unsigned char* pu8Km, 
                                          unsigned char* pu8Rn, 
                                          unsigned char* pu8Rtx, 
                                          unsigned char* pu8Rrx);

/// [API for TX]
/// Set Tx content key to TA
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8Ks                [IN]    [SENSITIVE]Session Key
/// @param pu8Lc128             [IN]    [SENSITIVE]Lc128
/// @param pu8Riv               [IN]    Riv
DLL_PUBLIC int HCS_SetTxContentKey(ST_HDCP_CA_SERVICE *pstHDCPService,
                                   unsigned char* pu8Ks, 
                                   unsigned char* pu8Lc128,
                                   unsigned char* pu8Riv);

/// [API for RX/TX] 
/// Set integrity key(Kd) to TA. Kd is used to compute HMAC-SHA256 including H, L, M, V.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8Km                [IN]    [SENSITIVE]Km
/// @param pu8Rn                [IN]    Derived from Tx
/// @param pu8Rtx               [IN]    Random derived from Tx
/// @param pu8Rrx               [IN]    Random derived from Rx (Add in hdcp2.2)
DLL_PUBLIC int HCS_SetIntegrityKey(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char* pu8Km, unsigned char* pu8Rn, unsigned char* pu8Rtx, unsigned char* pu8Rrx);

/// [API for RX/TX]
/// Set HDCP version and version info
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param u8ProtocolDescriptor [IN]    HDCP Protocol version defined in CertRx (Add in hdcp2.2) 
/// @param u8RxInfoVer          [IN]   Derived from Rx Info.
/// @param u16RxInfoMask        [IN]   Derived from Rx Info
/// @param u8TxInfoVer          [IN]   Derived from Tx Info
/// @param u16TxInfoMask        [IN]   Derived from Tx Info
DLL_PUBLIC int HCS_SetHDCPVersion(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char u8ProtocolDescriptor, unsigned char u8RxInfoVer, unsigned short u16RxInfoMask, unsigned char u8TxInfoVer, unsigned short u16TxInfoMask);

/// [API for RX/TX]
/// Get HDCP version
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param penHdcpVersion       [IN]    The current HDCP version
DLL_PUBLIC int HCS_GetHDCPVersion(ST_HDCP_CA_SERVICE *pstHDCPService, EN_HDCP_VERSION *penHdcpVersion);

/// [API for TX]
/// Get Riv in TX. 
/// @param pstHDCPService       [IN]    HDCP CA instance
DLL_PUBLIC int HCS_GetRiv(ST_HDCP_CA_SERVICE *pstHDCPService, char **pRiv, unsigned int *pRivLen);

/// [API for RX/TX] 
/// Compute H for Miracast.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8H                 [OUT]   H
/// @param pu8Kd                [IN]    [SENSITIVE] Kd
/// @param pu8Rtx               [IN]    Random derived from Tx
/// @param repeater             [IN]    Repeater flag
DLL_PUBLIC int HCS_ComputeH(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char* pu8H, unsigned char* pu8Kd, unsigned char* pu8Rtx, unsigned char repeater);

/// [API for RX/TX] 
/// Compute H for HDMI.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8H                 [OUT]   H
/// @param pu8Kd                [IN]    [SENSITIVE] Kd
/// @param pu8Rtx               [IN]    Random derived from Tx
/// @param pu8RxCaps            [IN]    RxCaps
/// @param pu8TxCaps            [IN]    TxCaps
DLL_PUBLIC int HCS_HDMI_ComputeH(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char* pu8H, unsigned char* pu8Kd, unsigned char* pu8Rtx, unsigned char* pu8RxCaps, unsigned char* pu8TxCaps);

/// [API for TX]
/// Compute L.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8L                 [OUT]    L
/// @param pu8Kd                [IN]    [SENSITIVE]Kd 
/// @param pu8Rrx               [IN]   Random derived from rx
/// @param pu8Rn                [IN]    Rn
/// @param PrecompL             [IN]    PrecompL or not
DLL_PUBLIC int HCS_ComputeL(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char* pu8L, unsigned char* pu8Kd, unsigned char* pu8Rrx, unsigned char* pu8Rn, unsigned char PrecompL);

/// [API for Reapter]
/// Compute M.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8M                 [OUT]   M
/// @param pu8Kd                [IN]    [SENSITIVE]Kd
/// @param pu8ManageStream      [IN]    pu8ManageStream
/// @param u32ManageStreamLen   [IN]    ManageStream Length
DLL_PUBLIC int HCS_ComputeM(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char* pu8M, unsigned char* pu8Kd, unsigned char* pu8ManageStream, unsigned int u32ManageStreamLen);

/// [API for Reapter]
/// Compute V.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8V                 [OUT]   V
/// @param pu8Kd                [IN]    [SENSITIVE]Kd
/// @param pu8RepAuthIdList     [IN]    pu8RepAuthIdList
/// @param u32RepAuthIdListLen  [IN]    RepAuthIdList Length
/// @param enVer              [IN]    hdcp version
DLL_PUBLIC int HCS_ComputeV(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char* pu8V, unsigned char* pu8Kd, unsigned char* pu8RepAuthIdList, unsigned int u32RepAuthIdListLen, EN_HDCP_VERSION enVer);


/// [API for TX/RX] 
/// Get Encrypted Content Key. This function can be called in Rx to handle non-standard Tx device.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8RxContentKey      [OUT]   Clear content key.
DLL_PUBLIC int HCS_GetEncryptedContentKey(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char** pu8RxContentKey);


//////////////////////////////////////////////////////////////////////////////////////////////////////
// Only support in DEBUG version for verification. Do not use the following API in product.
// The following API are calculated in TEE and will return sensitve data back to normal world  
////////////////////////////////////////////////////////////////////////////////////////////////////////

/// [API for RX] 
// Get Rx private key. Caller need to free pRxPrivKey.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pRxPrivKey           [OUT]   Rx private Key
/// @param pRxPrivKeyLen        [OUT]   Rx private Key Length
DLL_PUBLIC int HCS_GetRxPrivateKey(ST_HDCP_CA_SERVICE *pstHDCPService, char **pRxPrivKey, unsigned int *pRxPrivKeyLen);

/// [API for RX] 
/// Acquire Kd. Kd is used to compute H, L, M, V. 
/// To meet spec requirement, Kd should keep in the secure world even if Kd does not belong to keys to calculate content key. 
/// Please use HCS_SetIntegrityKey instead of HCS_ComputeKd in product
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8Kd                [OUT]   Kd 
/// @param pu8Km                [IN]    Km (Optional) 
/// @param pu8Rn                [IN]    Derived from Tx
/// @param pu8Rtx               [IN]    Random derived from Tx
DLL_PUBLIC int HCS_ComputeKd(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char* pu8Kd, unsigned char* pu8Km, unsigned char* pu8Rn, unsigned char* pu8Rtx, unsigned char* pu8Rrx);


////////////////////////////////////
/// d. Customization API
///////////////////////////////////

/// [API for RX]
/// Run the decryption function for TS packet
/// @param pidArray          [IN]     TS packet PID array list
/// @param pidArraySize      [IN]     TS packet PID array size
/// @param pBuf              [IN/OUT] Source and destination buffer
/// @param nBufLen           [IN]     Buffer length
/// @param aesKey            [IN]     AES key
/// @param RIV               [IN]     RIV key(Note: please fill 0x00 to meet 16 bytes due to hw request)
DLL_PUBLIC int HCS_AESDecryptTS(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned int *pidArray, unsigned int pidArraySize, unsigned char* const pBuf, unsigned int nBufLen, unsigned char *aesKey, unsigned char *RIV);


/// [API for LG Customer]
#if (LG_SUPPORT==1)

/// [API for RX] 
/// Get Rx Cert from Rx Private Key set. Caller need to free RxCert
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pRxCert              [OUT    Cert Rx
/// @param pRxCertLen           [OUT]   Cert Rx length
DLL_PUBLIC int HCS_GetRxCertificate(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char **pRxCert, unsigned int *pRxCertLen);

/// [API for RX]
/// Acquire PES. This Function is Decryption PES data
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8OutPut            [OUT]   PES Decryption Buffer
/// @param pu8InPut             [IN]    Encryption PES data
/// @param pu8Counter           [IN]    AES CTR Conter
/// @param inputLength          [IN]    PES Length(16byte)
DLL_PUBLIC int HCS_SetDecryptionPES(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pu8OutPut, unsigned char *pu8InPut,unsigned char *pu8Counter ,unsigned int inputLength);

/// [API for TX]
/// Get DCP LLC Public key from Tx device secret key set. Caller need to free DCP LLC Public Key
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pPublicKey           [OUT]   DCP LLC Public key defined in HDCP spec
/// @param pPublicKeyLen        [OUT]   length of DCP LLC Public key
DLL_PUBLIC int HCS_GetDCPLLCPublicKey(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char **pPublicKey, unsigned int *pPublicKeyLen);

/// [API for TX]
/// Write Key to Temperary Storage in TEE. This function store current Km to selected StoredKm Slot
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param index                [IN]    index of StoredKm Slot
DLL_PUBLIC int HCS_SetWriteStoredKm(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned int index);

/// [API for TX]
/// Acquire StoredKm from Temperary Storage in TEE. This Function select StoredKm Slot and reload the StoredKm to current Km
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param index                [IN]    index of StoredKm Slot
DLL_PUBLIC int HCS_SetSelectStoredKm(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned int index);

/// [API for RX/TX]
/// Set HDCP version and version info
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param VersionNumber		[IN]    HDCP Compute the Key depends on HDCP Version
DLL_PUBLIC int HCS_SetHDCPComputeVersion( ST_HDCP_CA_SERVICE *pstHDCPService, int VersionNumber);

/// [API for TX] 
/// Acquire RootPublicKey. This Function is Get RootPublicKey, and Encryption RootPublicKey
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pRootPublickey       [OUT]   A decrypted Root Public Key(Kpub.dcp)
/// @param src_file_path        [IN]    A encrypted TX Key Set file path
/// @param FileLength			[IN]	A encrypted TX Key Set file length
DLL_PUBLIC int HCS_GetRootPublicKey(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pRootPublickey, unsigned char *src_file_path, unsigned int FileLength);

DLL_PUBLIC int HCS_XOR_Ks_with_LC128(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pu8Edkey_ks, unsigned char * pu8Lc128);

DLL_PUBLIC int HCS_GetEncryptedKM(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char** pu8EncKm, unsigned int *pu32EncKmLen, unsigned char* pu8Km, unsigned char *pu8M, unsigned char *pu8Kpriv_rx, unsigned int u32Kpriv_rx_len);

DLL_PUBLIC int HCS_GetDecryptedKM(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pu8EncKm, unsigned char *pu8M, unsigned char *pu8Kpriv_rx, unsigned int u32Kpriv_rx_len);

DLL_PUBLIC int HCS_HMAC_SHA256(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pOutputBuf, unsigned char *pInputBuf, int length);
DLL_PUBLIC int HCS_GetProtectPESContentKey(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pData, unsigned int pLength);
DLL_PUBLIC int HCS_SetProtectPESContentKey(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pData, unsigned int pLength);

/// [API for RX] 
/// Acquire Kh. Kh is used to encrypted master key.
/// To meet spec requirement, Kh should keep in the secure world.
/// Please use HCS_GetEncryptedMasterKeyStored in Rx side instead of HCS_ComputeKh in product.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param pu8Kh                [OUT]   Kh
/// @param pu8Kpriv_rx          [IN]    Rx private key (Optional) 
/// @param u32Kpriv_rx_len      [IN]    Rx private key length
DLL_PUBLIC int HCS_ComputeKh(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char *pu8Kh, unsigned char * pu8Kpriv_rx, unsigned int u32Kpriv_rx_len);

#endif // LG_SUPPORT


////////////////////////////////////
/// e. HDMI
///////////////////////////////////

/// [API for RX]
/// After HDCP authenation completed, pass RIV and Content Key to specific HDMI port for process cipher.
/// [Note]: RIV and Content Key is stored in CA instance.
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param u8PortIdx            [IN]    HDMI port number
DLL_PUBLIC int HCS_ProcessCipher(ST_HDCP_CA_SERVICE *pstHDCPService, unsigned char u8PortIdx);

/// [API for Rx]
/// Set flag to note hdmi running or not.
/// @param u32IsHdmiRxRunning   [IN]    Note for HDMI is running
DLL_PUBLIC void SetHdmiRxRunning(unsigned int u32IsHdmiRxRunning);

/// [API for Rx]
/// Check HDMI running or not.
DLL_PUBLIC unsigned int IsHdmiRxRunning(void);

/// [API for RX]
/// Check HDMI with HDCP22 cipher state
/// @param pstHDCPService       [IN]    HDCP CA instance
/// @param u8PortIdx            [IN]    HDMI port index
/// @param u8PortState          [OUT]   HDMI port state
DLL_PUBLIC int HCS_GetCipherState(ST_HDCP_CA_SERVICE* pstHDCPService, unsigned char u8PortIdx, unsigned char* pu8State);


#ifdef __cplusplus
}
#endif


#endif
