/**
 * @file: app.h
 * @brief Part of the HDCP reference library.
 *
 * INTEL CONFIDENTIAL
 * Copyright 2010-2012 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef __APP_H_
#define __APP_H_

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef WIN32
#ifndef _WIN32_WINNT            // Specifies that the minimum required platform is Windows Vista.
#define _WIN32_WINNT 0x0600     // Change this to the appropriate value to target other versions of Windows.
#endif
#include "winsock2.h"

#ifndef s_addr
#define s_addr  S_un.S_addr
#endif

typedef void pthread_t;
#else
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdlib.h>
#include <syslog.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h> // For TCP_NODELAY
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#ifdef _POSIX_SOURCE
#include <assert.h>
#include <arpa/inet.h>
#define strtok_s    strtok_r
#define _snprintf_s(b, s, c, ...) snprintf(b, s, __VA_ARGS__)
#define _vsnprintf_s(b, s, c, ...) vsnprintf(b, s, __VA_ARGS__)
#endif

#define INVALID_SOCKET (-1)
#define SOCKET_ERROR (-1)
#define WINAPI

#define closesocket close
#define _snprintf snprintf

typedef void* LPVOID;
typedef int SOCKET;
typedef struct sockaddr_in SOCKADDR_IN;
typedef struct sockaddr SOCKADDR;
#endif

#include "hdcp.h"
#include "hdcpCommon.h"

#define IPADDR_LEN          16
#define TS_PACKET_SIZE      188

#define HDMI2SM             55
#define SM2HDMI             66

typedef struct {
    void*               hHdcp;
    void*               pCrypto;
    SOCKET              sockListen;
    SOCKET              sock;
    SOCKET              sockDispatcher;
    SOCKADDR_IN         saHostAddr;
    SOCKADDR_IN         saIpAddr;
    // add by MStar
    SOCKADDR_IN         saDispatcherAddr;
    HDCPBOOL            bReadyToConnect;
    HDCPBOOL            bConnected;
    HDCPBOOL            bRx;
    HDCPBOOL            bPrecompL;
    HDCPBOOL            bPrecompLParam;
    HDCPBOOL            bRxidListReceived;
    HDCPBOOL            bDownstreamRepeater;
    HDCPBOOL            bWaitForPATPMT;
    HDCPBOOL            bVerify;
    HDCPBOOL            bVerifyFailed;
    HDCPBOOL            bShutdown;
    uint8_t             DEVICE_COUNT;
    uint8_t             DEPTH;
    HDCP_RXID           rxidlist[MAX_DEVICE_COUNT];
    int                 nRepDownStreamIndex;
    uint8_t             ucVerMajor;
    uint8_t             ucVerMinor;
    uint8_t             ucProtDesc;
    int                 nVerbose;
    int                 nLogLevel;
    long                lTimeoutMultiplier;
    int                 nVectorOptions;
    uint8_t             u8TestVector;
    uint32_t            ulAuthState;
    HDCP_RXID           rxId;
    uint16_t            usHdcpPort;
    uint16_t            usHdcpDownStreamPort[MAX_DOWNSTREAM_PORTS];
    char                szDownStreamAddr[IPADDR_LEN+1][MAX_DOWNSTREAM_PORTS];
    uint32_t            ulDownStreamPorts;
    char                szPeerIPAddr[IPADDR_LEN+1];
    char                szHostIPAddr[IPADDR_LEN+1];
    char                szModule[25];
    char                szAppModule[25];
    char                szFileSrc[256];
    char                szFileDst[256];
    char                szFileIn[256];
    HDCPBOOL            hdcp_canceled;
#ifdef WIN32
    void*               hThread;
    void*               hThreadCtr;
#else
    pthread_t           hThread;
    pthread_t           hThreadCtr;
#endif
#ifdef WIN32
    long long           llFreq;
#endif

#define HDCP_BUFFER_SIZE 1024

    // data variables
    SOCKET              sockStreamSrc;
    SOCKET              sockStreamDst;
    SOCKADDR_IN         saStreamSrc;
    SOCKADDR_IN         saStreamDst;
    FILE*               fpdst;
    FILE*               fpsrc;
    FILE*               fpin;
    uint8_t             ucSrcFrame[HDCP_BUFFER_SIZE];
    uint8_t             ucDstFrame[HDCP_BUFFER_SIZE];
    uint64_t            ullInputCounter;
    uint32_t            ulStreamCtr;
    uint16_t            PMT_PID;
    uint16_t            PCR_PID;
    uint16_t            usVID_PID;//=(uint16_t)-1;
    uint16_t            usAUD_PID;//=(uint16_t)-1;
    uint8_t             video_continuity_counter;
    uint32_t            ulFrameSize;
    uint32_t            ulCopied;
    uint16_t            usVidPesID;
    uint16_t            usAudPesID;
    int                 nFrame;

    // add by MStar
    uint8_t             uPortNumber;
    EN_HDCP_TYPE        enHdcpType;
    Fn_MDrv_HDCP22_InitCBFunc      pFn_MDrv_HDCP22_InitCBFunc;
    Fn_MDrv_HDCP22_PortInit        pFn_MDrv_HDCP22_PortInit;
    Fn_MDrv_HDCP22_PollingReadDone pFn_MDrv_HDCP22_PollingReadDone;
    Fn_MDrv_HDCP22_EnableCipher    pFn_MDrv_HDCP22_EnableCipher;
    Fn_MDrv_HDCP22_SendMsg         pFn_MDrv_HDCP22_SendMsg;
    Fn_MDrv_HDCP22_Handler         pFn_MDrv_HDCP22_Handler;
    Fn_HDCP22_Error_CBF            pFn_HDCP22_Error_CBF;
    Fn_MDrv_HDCP22_FillCipherKey   pFn_MDrv_HDCP22_FillCipherKey;

    uint8_t                        u8IgnoreLog;
    int                            nMsgId;
} COMMON_DATA;

typedef struct 
{
    long mtype;
    int  mLen;
    char mtext[1024];
} ST_MSG_BUFFER;


// TODO: remove DLL_PUBLIC
#ifndef DLL_PUBLIC
#define DLL_PUBLIC __attribute__ ((visibility ("default")))
#endif


DLL_PUBLIC void Terminate_HDCP(COMMON_DATA* hdcp2_config);
DLL_PUBLIC void HDCP_Session_Reset(COMMON_DATA* hdcp2_config);
DLL_PUBLIC int hdcp_set_reasonable_defaults(COMMON_DATA* hdcp2_config);
DLL_PUBLIC int hdcp_set_tx_reasonable_defaults(COMMON_DATA* hdcp2_config);

DLL_PUBLIC int hdcp_rx_main(COMMON_DATA* hdcp2_config);
int hdcp2_tx_main(COMMON_DATA* pcd);
int hdcp2_tx_start_auth(COMMON_DATA* pcd);
int hdcp2_rx_main(COMMON_DATA* pcd);
int hdcp2_rx_start_auth(COMMON_DATA* pcd);
int hdcp2_init_tee(COMMON_DATA* pcd);
int hdcp2_deinit_tee(COMMON_DATA* pcd);

// Add by MStar to get encrypted content key for HDCP_Callback function
void GetEncryptedContentKey( uint8_t* pEncKey, uint8_t* pClearKey, uint32_t u32ClearKeyLen);


#ifdef __cplusplus
}
#endif

#endif // __APP_H_
