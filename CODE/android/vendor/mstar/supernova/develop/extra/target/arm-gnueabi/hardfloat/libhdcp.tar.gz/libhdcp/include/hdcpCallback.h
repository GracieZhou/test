
#ifndef __HDCP_CALL_BACK_H_
#define __HDCP_CALL_BACK_H_


#ifdef __cplusplus
extern "C"
{
#endif


/////////////////////////////////////////////////////
// HDCP Callback function definition
////////////////////////////////////////////////////

/// The following event should be implement by the regisster. You can get the sample code in MSrv_Widi.h
typedef enum
{
    /// Get HDCP key in Rx site.
    HDCP_EVENT_GET_HDCP_KEY,
    /// Aes 128 Key Set. This AES key is hdcp content key
    HDCP_EVENT_SET_AES128_KEY,
    /// Aes 128 Riv Set. This Riv is used to calcualte CTR value
    HDCP_EVENT_SET_AES128_RIVKEY,

    /// Get HDCP key in Tx site.
    HDCP_EVENT_TX_SET_AES128_KEY,

    /// Get HDCP error message.
    HDCP_EVENT_GET_HDCP_ERROR_MSG,

    /// Authenticated HDCP
    HDCP_EVENT_Authenticated_HDCP,

    /// Get HDCP Errata state
    HDCP_EVENT_GET_ERRATA_STATE,

    HDCP_EVENT_MAX_NUM,

}EN_HDCP_EVENT;

/// HDCP callback function defination
typedef void (* HDCP_EVENT_CB)(EN_HDCP_EVENT eventID, void * param, void *pUsrParam);
//typedef void (* HDCP_EVENT_CB)(void * Param, void *pUsrParam);

///HDCP event CB struct.
typedef struct
{
    /// Enable or Disable
    int       enable;
    /// Callback function
    HDCP_EVENT_CB     func;
    /// Caller pointer
    void            *pUsrParam;
} HdcpEventCB;


/////////////////////////////////////////////////////
// HDCP Callback function inner structure
////////////////////////////////////////////////////

/// HDCP key struct used in HDCP_EVENT_GET_HDCP_KEY
typedef struct {
    /// LC128
   unsigned char    cLC128[(128/8)];
    /// SHA_1
   unsigned char    cSHA_1[20];
    /// RXID
   unsigned char    cRXID[(40/8)];
    /// KPUBRX
   unsigned char    cKPUBRX[(1048/8)];
    /// CERT_RESERVED
   unsigned char    cCERT_RESERVED[(16/8)];
    /// CERT_SIGN
   unsigned char    cCERT_SIGN[(3072/8)];
    /// KPRIVRX
   unsigned char    cKPRIVRX[(2560/8)];
    /// SHA_1p
   unsigned char    cSHA_1p[20];
    /// KPRIVRX_D
   unsigned char    cKPRIVRX_D[(1024/8)];
} ST_HdcpKeyStruct;

#ifndef DLL_PUBLIC
#define DLL_PUBLIC __attribute__ ((visibility ("default")))
#endif

/// register HDCP call back function.
/// @param eHdcpEventID     [IN]    HDCP CB enum 
/// @param hdcp_cb          [IN]    HDCP callback function
/// @param pUsrParam       [IN]    user param which can be used in HDCP_CB_EXEC
DLL_PUBLIC int  HDCP_registerEventCB(EN_HDCP_EVENT eHdcpEventID, HDCP_EVENT_CB hdcp_cb, void *pUsrParam);

/// unregister HDCP call back function.
/// @param eHdcpEventID     [IN]    HDCP CB enum 
DLL_PUBLIC int  HDCP_unRegisterEventCB(EN_HDCP_EVENT eHdcpEventID);

/// HDCP Callback function
/// @param eHdcpEventID     [IN]    HDCP CB enum 
DLL_PUBLIC void HDCP_CB_EXEC(EN_HDCP_EVENT eHdcpEventID, void * Param);

#ifdef __cplusplus
}
#endif

#endif // __HDCP_CALL_BACK__H_
